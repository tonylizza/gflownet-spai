# GFlowNet for SPAI in PyTorch

This repo is associated with Tony Lizza's Master's thesis. It is based on and forked from the repo ["GFlotNet in PyTorch"](https://github.com/augustwester/gflownet/tree/main), which implements a Generative Flow Network (GFlowNet), proposed by Bengio et al. in the paper ["Flow Network based Generative Models for Non-Iterative Diverse Candidate Generation"](https://arxiv.org/abs/2106.04399) (2021). 

Additional details to follow.
